from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash

db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(80), unique=True, nullable=False)
    username = db.Column(db.String(80), nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def __init__(self, userid, username, password):
        self.userid = userid
        self.username = username
        self.password_hash = generate_password_hash(password)


class Menu(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    url = db.Column(db.String(200), nullable=False)
    parent_id = db.Column(db.Integer, db.ForeignKey('menu.id'), nullable=True)
    submenu = db.relationship('Menu', backref=db.backref('parent', remote_side=[id]))
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<Menu {self.name}>'


class DbInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.Integer, nullable=False)
    dbalias = db.Column(db.String(120), nullable=False)
    dbname = db.Column(db.String(120), nullable=False)
    user = db.Column(db.String(120), nullable=False)
    password = db.Column(db.String(120), nullable=False)
    host = db.Column(db.String(120), nullable=False)
    port = db.Column(db.String(120), nullable=False)
    is_active = db.Column(db.Boolean, default=False)

    def __init__(self, dbalias, userid, dbname, user, password, host, port, is_active):
        self.dbalias = dbalias
        self.userid = userid
        self.dbname = dbname
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.is_active = is_active
