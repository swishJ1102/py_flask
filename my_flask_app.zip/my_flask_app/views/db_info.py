from flask import Blueprint, render_template, redirect, url_for, session, flash, request
from flask_login import login_required
from flask_wtf import FlaskForm
from sqlalchemy import desc
from wtforms import StringField, SubmitField, BooleanField
from wtforms.validators import InputRequired, Length

from models import DbInfo
from models import db

dbinfo_bp = Blueprint('db_info', __name__)


class DbInfoForm(FlaskForm):
    dbalias = StringField('データベース名', validators=[InputRequired(), Length(min=4, max=80)])
    dbname = StringField('データベース', validators=[InputRequired(), Length(min=4, max=80)])
    user = StringField('ユーザー', validators=[InputRequired(), Length(min=4, max=80)])
    password = StringField('パスワード', validators=[InputRequired(), Length(min=4, max=80)])
    host = StringField('ホスト', validators=[InputRequired(), Length(min=4, max=80)])
    port = StringField('ポート', validators=[InputRequired(), Length(min=4, max=80)])
    is_active = BooleanField('アクティブ', default=False)
    register = SubmitField('登録')
    update = SubmitField('更新')
    cancel = SubmitField('キャンセル')


@dbinfo_bp.route('/db_info', methods=['GET', 'POST'])
def db_info():
    form = DbInfoForm()
    db_user_info = DbInfo.query.filter_by(userid=session['user_id']).order_by(desc(DbInfo.id)).all()

    if form.cancel.data:
        return redirect(url_for('menu.index'))

    if form.register.data:
        return render_template('db_info.html', form=form, db_infos=None, add_flag=False)

    return render_template('db_info.html', form=form, db_infos=db_user_info, add_flag=True)


@dbinfo_bp.route('/add_info', methods=['GET', 'POST'])
def add_info():
    form = DbInfoForm()
    if form.validate_on_submit():
        try:
            # 查询所有除了当前用户以外的记录
            records = DbInfo.query.filter_by(userid=session['user_id']).all()

            # 更新每条记录
            for record in records:
                record.is_active = False

            new_info = DbInfo(
                userid=session['user_id'],
                dbalias=form.dbalias.data,
                dbname=form.dbname.data,
                user=form.user.data,
                password=form.password.data,
                host=form.host.data,
                port=form.port.data,
                is_active=True
            )
            db.session.add(new_info)
            db.session.commit()
            flash('Database information added successfully.', 'success')
            return redirect(url_for('db_info.db_info'))
        except Exception as e:
            flash(f'Error adding information: {e}', 'danger')
            db.session.rollback()
    db_user_info = DbInfo.query.filter_by(userid=session['user_id']).order_by(desc(DbInfo.id)).all()
    return render_template('db_info.html', form=form, db_infos=db_user_info, add_flag=True)


@dbinfo_bp.route('/edit_info', methods=['GET', 'POST'])
def edit_info():
    info_id = request.args.get('id')
    info = DbInfo.query.filter_by(id=info_id, userid=session['user_id']).first_or_404()
    form = DbInfoForm(obj=info)
    try:
        info.dbalias = form.dbalias.data
        info.dbname = form.dbname.data
        info.user = form.user.data
        info.password = form.password.data
        info.host = form.host.data
        info.port = form.port.data
        info.is_active = form.is_active.data
        db.session.commit()
        flash('Database information updated successfully.', 'success')
        # return redirect(url_for('db_info.db_info'))
    except Exception as e:
        flash(f'Error updating information: {e}', 'danger')
        db.session.rollback()
    return redirect(url_for('db_info.db_info'))


@dbinfo_bp.route('/delete_info', methods=['GET', 'POST'])
def delete_info():
    info_id = request.args.get('id')
    info = DbInfo.query.filter_by(id=info_id, userid=session['user_id']).first_or_404()
    try:
        db.session.delete(info)
        db.session.commit()
        flash('Database information deleted successfully.', 'success')
    except Exception as e:
        flash(f'Error deleting information: {e}', 'danger')
        db.session.rollback()
    return redirect(url_for('db_info.db_info'))
