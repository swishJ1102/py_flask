from flask import Blueprint, render_template, request, flash
import os
import pandas as pd

compare_db_bp = Blueprint('compare_db', __name__)


@compare_db_bp.route('/compare_db', methods=['GET', 'POST'])
def compare_db():
    if request.method == 'POST':
        folder1 = request.form['folder1']
        folder2 = request.form['folder2']

        if not os.path.isdir(folder1) or not os.path.isdir(folder2):
            flash('One or both of the directories do not exist.')
            return render_template('compare_db.html')

        differences = {}
        for file_name in os.listdir(folder1):
            file1 = os.path.join(folder1, file_name)
            file2 = os.path.join(folder2, file_name)

            if os.path.isfile(file2):
                df1 = pd.read_csv(file1)
                df2 = pd.read_csv(file2)

                # 比较数据
                diff = df1.compare(df2)
                if not diff.empty:
                    differences[file_name] = diff.to_html()

        return render_template('compare_db.html', differences=differences)
    return render_template('compare_db.html')
