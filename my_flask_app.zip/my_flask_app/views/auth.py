import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, session
from flask_wtf import FlaskForm
from werkzeug.security import check_password_hash
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import InputRequired, Length

from models import db, User

auth_bp = Blueprint('auth', __name__)


class LoginForm(FlaskForm):
    userid = StringField('ユーザー', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('パスワード', validators=[InputRequired(), Length(min=4, max=80)])
    submit = SubmitField('ログイン')


class RegisterForm(FlaskForm):
    userid = StringField('ユーザーID', validators=[InputRequired(), Length(min=4, max=15)])
    username = StringField('ユーザー名', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('パスワード', validators=[InputRequired(), Length(min=4, max=80)])
    submit = SubmitField('登録')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(userid=form.userid.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            session['user_id'] = user.id
            session['userid'] = user.userid
            session['username'] = user.username
            session['login_time'] = str(datetime.datetime.now())
            return redirect(url_for('menu.index'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user is None:
            new_user = User(userid=form.userid.data, username=form.username.data, password=form.password.data)
            db.session.add(new_user)
            db.session.commit()
            session['user_id'] = new_user.id
            session['userid'] = new_user.userid
            session['username'] = new_user.username
            session['login_time'] = str(datetime.datetime.now())
            return redirect(url_for('menu.index'))
        else:
            flash('Username already exists.', 'danger')
    return render_template('register.html', form=form)


@auth_bp.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('userid', None)
    session.pop('username', None)
    return redirect(url_for('auth.login'))
