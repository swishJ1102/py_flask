from flask import Blueprint, send_file, flash, redirect, request, url_for, session, render_template
import psycopg2
import os
import csv

from models import DbInfo

export_db_bp = Blueprint('export_db', __name__)

POSTGRES_DB = ''
POSTGRES_USER = ''
POSTGRES_PASSWORD = ''
POSTGRES_HOST = ''
POSTGRES_PORT = ''


@export_db_bp.route('/export_db')
def export_db():
    db_user_info = DbInfo.query.filter_by(userid=session['user_id']).all()
    if db_user_info is None:
        flash('利用可能なデータベース情報はありません', 'danger')
    # db_user_info = DbInfo.query.filter_by(userid=session['user_id']).first()
    # if db_user_info is None:
    #     flash('Database Info has not been set up yet.', 'danger')
    #     return redirect(url_for('menu.index'))
    # else:
    #     pass
    #     flash('good job.', 'success')
    # conn = psycopg2.connect(
    #     database=db_user_info.dbname,
    #     user=db_user_info.user,
    #     password=db_user_info.password,
    #     host=db_user_info.host,
    #     port=db_user_info.port
    # )
    # cursor = conn.cursor()
    #
    # # cursor.execute("""
    # #     SELECT table_schema, table_name
    # #     FROM information_schema.tables
    # #     WHERE table_type = 'BASE TABLE'
    # #     ORDER BY table_schema, table_name;
    # # """)
    # # schema = cursor.fetchall()
    # if db_user_info.dbname.find("cis") >= 0:
    #     schema = 'unisys'
    # else:
    #     schema = 'public'
    #
    # # 导出所有表
    # cursor.execute(f"""
    #     SELECT table_name
    #     FROM information_schema.tables
    #     WHERE table_schema='{schema}'
    # """)
    # tables = cursor.fetchall()
    # if len(tables) == 0:
    #     flash('no table has been found.', 'danger')
    #     return redirect(url_for('menu.index'))
    #
    # export_dir = 'exports'
    # os.makedirs(export_dir, exist_ok=True)
    #
    # for table_name in tables:
    #     table_name = table_name[0]
    #     file_path = os.path.join(export_dir, f'{table_name}.csv')
    #     with open(file_path, 'w', encoding='utf-8') as f:
    #         writer = csv.writer(f)
    #         cursor.copy_expert(f"COPY {table_name} TO STDOUT WITH CSV HEADER", f)
    #
    # cursor.close()
    # conn.close()
    #
    # return send_file(file_path, as_attachment=True)
    return render_template('export_db.html', db_infos=db_user_info)
