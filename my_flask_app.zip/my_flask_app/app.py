from flask import Flask, redirect, url_for, request, session, flash

from models import db, User, Menu
from views.auth import auth_bp
from views.compare_db import compare_db_bp
from views.db_info import dbinfo_bp
from views.export_db import export_db_bp
from views.menu import menu_bp

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'your_secret_key'

db.init_app(app)

# 注册蓝图
app.register_blueprint(auth_bp)
app.register_blueprint(menu_bp)
app.register_blueprint(dbinfo_bp)
app.register_blueprint(export_db_bp)
app.register_blueprint(compare_db_bp)


def init_db():
    with app.app_context():
        db.create_all()

        if not Menu.query.first():
            db.session.add_all([
                Menu(name='データベース情報', url='/db_info'),
                Menu(name='データベース　エクスポート', url='/export_db'),
                Menu(name='データベース　比較', url='#', submenu=[
                    Menu(name='データベース　比較1', url='/compare_db'),
                    Menu(name='データベース　比較2', url='/compare_db')
                ]),
                Menu(name='イメージ　比較', url='/export_db')
            ])
            db.session.commit()


@app.before_request
def check_login():
    if request.endpoint in ['register', 'logout', 'menu.index', 'export_db.export_db', 'compare_db.compare_db'
                            ] and 'user_id' not in session:
        flash('Please login before processing...', 'danger')
        return redirect(url_for('auth.login'))


@app.route('/')
def welcome():
    return redirect(url_for('auth.login'))


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
